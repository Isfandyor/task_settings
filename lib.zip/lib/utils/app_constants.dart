import 'package:flutter/material.dart';

class AppConstants {
  static ThemeMode themeMode = ThemeMode.light;
  static String backgroundImage = "";
  static String language = "uz";
  static double fontSizeText = 15;
  static String? passwordApp;
  static String passoword = "1234";
}
