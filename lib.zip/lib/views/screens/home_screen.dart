import 'package:flutter/material.dart';
import 'package:practice_2/utils/app_constants.dart';
import 'package:practice_2/views/widgets/custom_drawer.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<bool> onThemeChanged;
  const HomeScreen({
    super.key,
    required this.onThemeChanged,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Bosh Sahifa",
          style: TextStyle(fontSize: AppConstants.fontSizeText),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              AppConstants.language,
              style: TextStyle(fontSize: AppConstants.fontSizeText),
            ),
          )
        ],
      ),
      drawer: CustomDrawer(
        onThemeChanged: widget.onThemeChanged,
      ),
      body: Container(
        decoration: BoxDecoration(
          image: AppConstants.backgroundImage.isNotEmpty
              ? DecorationImage(
                  image: NetworkImage(
                    AppConstants.backgroundImage,
                  ),
                  fit: BoxFit.cover)
              : null,
        ),
      ),
    );
  }
}
