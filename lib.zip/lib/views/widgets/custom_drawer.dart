import 'package:flutter/material.dart';
import 'package:practice_2/utils/app_constants.dart';
import 'package:practice_2/views/screens/home_screen.dart';
import 'package:practice_2/views/screens/password_screen.dart';
import 'package:practice_2/views/screens/settings_screen.dart';

class CustomDrawer extends StatelessWidget {
  final ValueChanged<bool> onThemeChanged;
  const CustomDrawer({super.key, required this.onThemeChanged});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage(
              AppConstants.backgroundImage,
            ),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Colors.amber,
              ),
              child: Center(
                child: Text(
                  "User",
                  style: TextStyle(fontSize: AppConstants.fontSizeText + 5),
                ),
              ),
            ),
            ListTile(
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (ctx) {
                      return HomeScreen(
                        onThemeChanged: onThemeChanged,
                      );
                    },
                  ),
                );
              },
              title: Text(
                "Bosh sahifa",
                style: TextStyle(fontSize: AppConstants.fontSizeText),
              ),
              trailing: const Icon(
                Icons.keyboard_arrow_right,
              ),
            ),
            ListTile(
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (ctx) {
                      return SettingsScreen(
                        onThemeChanged: onThemeChanged,
                      );
                    },
                  ),
                );
              },
              title: Text(
                "Sozlamalar",
                style: TextStyle(fontSize: AppConstants.fontSizeText),
              ),
              trailing: const Icon(
                Icons.keyboard_arrow_right,
              ),
            ),
            ListTile(
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (ctx) {
                      return PasswordScreen(onThemeChanged: onThemeChanged);
                    },
                  ),
                );
              },
              title: Text(
                "Sozlamalar",
                style: TextStyle(fontSize: AppConstants.fontSizeText),
              ),
              trailing: const Icon(
                Icons.lock,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
